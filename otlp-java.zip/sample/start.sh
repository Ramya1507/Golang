#!/bin/bash

java -jar /usr/src/app/target/sample-0.0.1-SNAPSHOT.jar --server.port=5000 
